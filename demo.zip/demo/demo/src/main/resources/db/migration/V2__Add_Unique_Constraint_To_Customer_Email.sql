ALTER TABLE customer
ADD CONSTRAINT customer_email_unique UNIQUE (email);